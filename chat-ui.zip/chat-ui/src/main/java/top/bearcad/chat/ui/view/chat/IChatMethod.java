package top.bearcad.chat.ui.view.chat;

/**
 * @program: chat-ui
 * @description:
 * @author: bearcad
 * @create: 2021-10-23 00:16
 **/

/**
 * 方法接口
 * @author Bear
 */
public interface IChatMethod {
    /**
     * 打开窗口
     */
    void doShow();

}
