package top.bearcad.chat.ui;

/**
 * @program: chat-ui
 * @description:
 * @author: bearcad
 * @create: 2021-10-21 23:04
 **/

import javafx.application.Application;
import javafx.stage.Stage;
import top.bearcad.chat.ui.view.chat.ChatController;
import top.bearcad.chat.ui.view.chat.IChatMethod;

import java.io.IOException;

/**
 * 启动主类
 * @author Bear
 */
public class Main extends Application {

    //@Override
    //public void start(Stage stage) throws IOException {
    //    ILoginMethod login = new LoginController((userId, userPassword) -> {
    //        System.out.println("登陆 userId：" + userId + "userPassword：" + userPassword);
    //    });
    //
    //    login.doShow();
    //}

    @Override
    public void start(Stage stage) throws IOException {
        IChatMethod chat = new ChatController();
        chat.doShow();
    }


    public static void main(String[] args) {
        launch(args);
    }
}