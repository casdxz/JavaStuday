package top.bearcad.chat.ui.view.chat;

/**
 * @program: chat-ui
 * @description:
 * @author: bearcad
 * @create: 2021-10-23 00:16
 **/

/**
 * 事件接口
 * @author Bear
 */
public interface IChatEvent {

}
